'use strict'

module.exports = (object) => {
  return JSON.stringify(object)
}
