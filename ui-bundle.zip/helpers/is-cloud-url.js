;(function () {
  'use strict'

  const currentUrl = window.location.href
  const searchString = 'cloud'

  return currentUrl.includes(searchString)
})()
