'use strict'

module.exports = (a) => JSON.parse(a)
