'use strict'

module.exports = (a) => JSON.stringify(a, null, 2)
